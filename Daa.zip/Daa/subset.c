#include<stdio.h>
int k,s[10];
void push(int ele)
{
	k++;
	s[k]=ele;
}
int pop()
{
	return s[k--];
}
main()
{
	int n,m,j,flag=0;
	printf("Enter no. of elements : ");
	scanf("%d",&n);
	int a[n],i,sum=0,t=0,r[n];
	printf("Enter %d elements : ",n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
		sum+=a[i];
		r[i]=0;
	}
	printf("Enter the weight : ");
	scanf("%d",&m);
	i=0,k=-1;
	printf("\nThe subsets are :\n");
	while(1)
	{
		if((i>=n && t==0)||m==0)
			break;
		if(t+a[i]<=m)
		{
			push(i);
			t=t+a[i];
		}
		if(t==m)
		{
			int p;
			flag=1;
			for(j=0;j<=k;j++)
			{
				r[s[j]]=1;
			}
			printf("[ ");
			for(p=0;p<n;p++)
			{
				printf("%d ",r[p]);
				r[p]=0;//clearing the value fot next subset
			}
			printf("]\n");
			int h=pop();
			t=t-a[h];
			i=h+1;
		}
		else
			i++;
		if(i>=n && t!=0)
		{
			int g=pop();
			t=t-a[g];
			i=g+1;
		}
	}
	if(flag==0)
		printf("There are no subsets which satisfy bounding condition");
}

