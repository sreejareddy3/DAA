#include<stdio.h>
#include<math.h>
int main()
{
	int n,m,i,j,k;
	printf("\nenter number of elements: ");
	scanf("%d",&n);
	int weight[n],profit[n],def[n];
	float unit[n],seq[n];
	printf("\nenter weight and profit of all elements:");
	printf("\nWEIGHT    PROFIT\n");
	for (i=0;i<n;i++)
	{
		scanf("%d %d",&weight[i],&profit[i]);
		float x=(float)profit[i]/weight[i];
		unit[i]=x;
		seq[i]=0;
		def[i]=i;
		
	}
	printf("\nbefpre sorting\n");
	for (i=0;i<n;i++)
		printf("%.2f ",unit[i]);
	
	float t;
	printf("\nenter maximum weight:");
	scanf("%d",&m);
	for( i=0;i<n-1;i++)
	{
		for( j=i+1;j<n;j++)
		{
			if(unit[i]<unit[j])
			{
				t=profit[i];
				profit[i]=profit[j];
				profit[j]=t;
				t=weight[i];
				weight[i]=weight[j];
				weight[j]=t;
				t=unit[i];
				unit[i]=unit[j];
				unit[j]=t;
				int te=def[i];
				def[i]=def[j];
				def[j]=te;
				}	
		}
	}
	printf("\n");
	float weigh=m;
	i=0;
	float gain=0;
	while (i<n)
	{
		if (weigh>weight[i])
		{
			weigh=weigh-weight[i];
			gain=gain+profit[i];
			int k=def[i];
			seq[k]=1;
		}
		else
		{
			gain=gain+(profit[i]*(weigh/weight[i]));
			float l=weigh/weight[i];
			weigh=weigh-(weight[i]*(weigh/weight[i]));
			int k=def[i];
			seq[k]=l;
			break;
			
		}
		i++;
	}
	printf("\nAfter sorting profit/weight values are:\n");
	for (i=0;i<n;i++)
		printf("%.2f ",unit[i]);
	printf("\nsequence is:\n");
	for (i=0;i<n;i++)
		printf("%.2f ",seq[i]);
	
	printf("\nprofit:%.2f",gain);
	return 0;
}

