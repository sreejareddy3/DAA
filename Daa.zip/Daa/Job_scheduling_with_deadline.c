#include<stdio.h>
int main(){
	int n;
	printf("\nenter number of jobs : ");
	scanf("%d",&n);
	int job[n],p[n],d[n],i,max=0;
	printf("\nenter deadlines of jobs : ");
	for( i=0;i<n;i++)
	{
		scanf("%d",&d[i]);
		job[i]=i+1;
		if (d[i]>max)
			max=d[i];
					
	}
	int a[max];
	for (i=0;i<max;i++)
		a[i]=-1;
	printf("\nenter profits of jobs : ");
	for( i=0;i<n;i++)
	{
		scanf("%d",&p[i]);
	}
	int t,j;
	for( i=0;i<n-1;i++)
	{
		for( j=i+1;j<n;j++)
		{
			if(p[i]<p[j])
			{
				t=p[i];
				p[i]=p[j];
				p[j]=t;
				t=d[i];
				d[i]=d[j];
				d[j]=t;
				t=job[i];
				job[i]=job[j];
				job[j]=t;
				
				}	
		}
	}
	int s=0;
	printf("\nsequence:");
	for (i=0;i<n;i++)
	{
		if (a[d[i]-1]==-1)
		{
			s=s+p[i];
			a[d[i]-1]=job[i];
			
		}
		else
		{
			for (j=0;j<d[i];j++)
			{
				if (a[j]==-1)
				{
					s=s+p[i];
					a[j]=job[i];
					break;
				}
			}
		}
	}
	for (i=0;i<max;i++)
		printf("%d ",a[i]);
	printf("\nprofit=%d",s);
	return 0;
}


