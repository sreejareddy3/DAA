#include<stdio.h>

int main()
{
	int n,h;
	printf("\nenter number of vertices:");
	scanf("%d",&n);
	int cost[n][n],i,j,visit[n],temp[n];
	printf("\nenter adjacency matrix:");
	for (i=0;i<n;i++)
	{
		visit[i]=0;
		for (j=0;j<n;j++)
		{
			scanf("%d",&cost[i][j]);
		}
	}
	int min_arr[n][n];
	visit[0]=1;
	

	
	int dist[n],min1=999,k,g;
	for (h=1;h<n;h++)
	{
		temp[0]=0;
		visit[h]=1;
		k=h;
		temp[1]=k;
		int p=2;
		int co=cost[0][k],t=k; 
	int min=9999;
	for (j=0;j<n;j++)
	{
		if (visit[j]!=1)
		{
			
		co=cost[0][t];
		co+=cost[t][j];
		visit[j]=1;
		temp[p++]=j;
		k=j;
	for (i=0;i<n;i++)
	{
		if (visit[i]!=1)
		{
			co+=cost[k][i];
			temp[p++]=i;
			k=i;
		}
	}
	co+=cost[k][0];
	visit[j]=0;
	if (co<min)
	{
		min=co;
		int s;
		for (s=0;s<n;s++)
		{
			min_arr[h][s]=temp[s];
		}
		p=2;
	}
		
}
}
		dist[h]=min;
		printf("%d\n",dist[h]);
		printf("\n\n minimum path from 0 to 0 via %d: ",h);
		int x;
		for (x=0;x<n;x++)
		printf("%d ",min_arr[h][x]);
		printf("\n\n");
		if (min1>dist[h])
		{
			min1=dist[h];
			g=h;
		}
			
		visit[h]=0;
	}
	printf("\nmin distance from 1 to 1 is =%d passing through %d vertex\n\n",min1,g);
	printf("PATH : ");
	for (i=0;i<n;i++)
		printf(" %d ->",min_arr[g][i]);
	printf(" 0");
	
	
	return 0;
}

