#include<stdio.h>
int max(int a, int b)
 {
  if (a>b) 
	return a;
  else
	return b; 
} 
void knapsack(int m, int wt[], int p[], int n) 
{ 
	int i, w; 
	int K[n + 1][m + 1]; 
	for (i = 0; i <= n; i++) { 
		for (w = 0; w <= m; w++) { 
			if (i == 0 || w == 0) 
				K[i][w] = 0; 
			else if (wt[i - 1] <= w) 
				K[i][w] = max(p[i - 1] + 
					K[i - 1][w - wt[i - 1]], K[i - 1][w]); 
			else
				K[i][w] = K[i - 1][w]; 
		} 
	} 

	int c[n];
	for( i=0;i<n;i++)
	{
		c[i]=0;
	}
	int res = K[n][m];	
	printf("\ntotal Max profit : "); 
	printf("%d\n", res); 
	
	w = m; 
	for (i = n; i > 0 && res > 0; i--) {
		if (res == K[i - 1][w]) 
			continue;		 
		else {
			c[i-1]=1;
			res = res - p[i - 1]; 
			w = w - wt[i - 1]; 
		} 
	}
	printf("\n ratio of weights of objects considered :\n");
	for( i=0;i<n;i++)
	{
		printf("%d ",c[i]);
	 } 
} 
int main() 
{ 
int n;
printf("\nEnter number of elements:");
	scanf("%d",&n);
	int knap[n][n];
	int m,i;
	int w[n],p[n];
	printf("\nEnter Weights : ");
	for( i=0;i<n;i++)
	{
		scanf("%d",&w[i]);
	}
	printf("\nEnter Profits : ");
	for( i=0;i<n;i++)
	{
		scanf("%d",&p[i]);
	}
	printf("\nEnter total weight : ");
	scanf("%d",&m);
	knapsack(m,w,p,n); 
	
	return 0; 
}





